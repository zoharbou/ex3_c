/*
 * heat_eqn.h
 *
 *  Created on: Apr 18, 2018
 *      Author: OWNER
 */

#ifndef HEAT_EQN_H_
#define HEAT_EQN_H_

double heat_eqn(double cell, double right, double top, double left, double bottom);

#endif /* HEAT_EQN_H_ */

